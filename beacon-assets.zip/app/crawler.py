def crawl_site(url):
    return [url]
