from app.crawler import crawl_site
print("Beacon Assets")
